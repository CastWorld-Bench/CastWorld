# Abilene-SEA-NYC

Released source series. See the dataset metadata for frequency, target, and chronological splits.

## Field definitions

| 字段名             | 字段的种类   | 字段的含义简介                     | 字段的缺失率 |
| --------------- | ------- | --------------------------- | ------ |
| `timestamp`     | 时间/截止时点 | 交通时间戳                       | 0%     |
| `STTLng_NYCMng` | 待预测值    | 待预测变量：STTLng 到 NYCMng 的网络流量 | 0%     |

| 字段名             | 字段的种类        | 字段的含义简介               | 字段的缺失率 |
| --------------- | ------------ | --------------------- | ------ |
| `ATLAM5_NYCMng**` | 数值型外生·同刻历史流量 | ATLAM5 到 NYCMng 的网络流量 | 11.96% |
| `ATLAng_CHINng**` | 数值型外生·同刻历史流量 | ATLAng 到 CHINng 的网络流量 | 0.003% |
| `ATLAng_KSCYng**` | 数值型外生·同刻历史流量 | ATLAng 到 KSCYng 的网络流量 | 0.47%  |
| `ATLAng_NYCMng**` | 数值型外生·同刻历史流量 | ATLAng 到 NYCMng 的网络流量 | 0.02%  |
| `ATLAng_SNVAng**` | 数值型外生·同刻历史流量 | ATLAng 到 SNVAng 的网络流量 | 2.65%  |
| `ATLAng_STTLng**` | 数值型外生·同刻历史流量 | ATLAng 到 STTLng 的网络流量 | 0.03%  |
| `ATLAng_WASHng**` | 数值型外生·同刻历史流量 | ATLAng 到 WASHng 的网络流量 | 0.003% |
| `CHINng_NYCMng**` | 数值型外生·同刻历史流量 | CHINng 到 NYCMng 的网络流量 | 0.003% |
| `CHINng_SNVAng**` | 数值型外生·同刻历史流量 | CHINng 到 SNVAng 的网络流量 | 0.02%  |
| `CHINng_STTLng**` | 数值型外生·同刻历史流量 | CHINng 到 STTLng 的网络流量 | 0.01%  |
| `CHINng_WASHng**` | 数值型外生·同刻历史流量 | CHINng 到 WASHng 的网络流量 | 0.003% |
| `DNVRng_ATLAng**` | 数值型外生·同刻历史流量 | DNVRng 到 ATLAng 的网络流量 | 0%     |
| `DNVRng_KSCYng**` | 数值型外生·同刻历史流量 | DNVRng 到 KSCYng 的网络流量 | 0.03%  |
| `DNVRng_NYCMng**` | 数值型外生·同刻历史流量 | DNVRng 到 NYCMng 的网络流量 | 0.003% |
| `DNVRng_STTLng**` | 数值型外生·同刻历史流量 | DNVRng 到 STTLng 的网络流量 | 0%     |
| `HSTNng_CHINng**` | 数值型外生·同刻历史流量 | HSTNng 到 CHINng 的网络流量 | 0.003% |
| `HSTNng_NYCMng**` | 数值型外生·同刻历史流量 | HSTNng 到 NYCMng 的网络流量 | 0.09%  |
| `HSTNng_STTLng**` | 数值型外生·同刻历史流量 | HSTNng 到 STTLng 的网络流量 | 0.08%  |
| `IPLSng_ATLAng**` | 数值型外生·同刻历史流量 | IPLSng 到 ATLAng 的网络流量 | 0.03%  |
| `IPLSng_CHINng**` | 数值型外生·同刻历史流量 | IPLSng 到 CHINng 的网络流量 | 0.03%  |
| `IPLSng_NYCMng**` | 数值型外生·同刻历史流量 | IPLSng 到 NYCMng 的网络流量 | 0.03%  |
| `IPLSng_SNVAng**` | 数值型外生·同刻历史流量 | IPLSng 到 SNVAng 的网络流量 | 0.24%  |
| `IPLSng_STTLng**` | 数值型外生·同刻历史流量 | IPLSng 到 STTLng 的网络流量 | 0.06%  |
| `KSCYng_CHINng**` | 数值型外生·同刻历史流量 | KSCYng 到 CHINng 的网络流量 | 0.09%  |
| `KSCYng_NYCMng**` | 数值型外生·同刻历史流量 | KSCYng 到 NYCMng 的网络流量 | 0.12%  |
| `KSCYng_SNVAng**` | 数值型外生·同刻历史流量 | KSCYng 到 SNVAng 的网络流量 | 1.76%  |
| `KSCYng_STTLng**` | 数值型外生·同刻历史流量 | KSCYng 到 STTLng 的网络流量 | 0.33%  |
| `LOSAng_ATLAM5**` | 数值型外生·同刻历史流量 | LOSAng 到 ATLAM5 的网络流量 | 4.80%  |
| `LOSAng_IPLSng**` | 数值型外生·同刻历史流量 | LOSAng 到 IPLSng 的网络流量 | 0.08%  |
| `LOSAng_KSCYng**` | 数值型外生·同刻历史流量 | LOSAng 到 KSCYng 的网络流量 | 0.11%  |
| `LOSAng_NYCMng**` | 数值型外生·同刻历史流量 | LOSAng 到 NYCMng 的网络流量 | 0.08%  |
| `LOSAng_STTLng**` | 数值型外生·同刻历史流量 | LOSAng 到 STTLng 的网络流量 | 0.08%  |
| `NYCMng_ATLAM5**` | 数值型外生·同刻历史流量 | NYCMng 到 ATLAM5 的网络流量 | 1.00%  |
| `NYCMng_ATLAng**` | 数值型外生·同刻历史流量 | NYCMng 到 ATLAng 的网络流量 | 0.06%  |
| `NYCMng_CHINng**` | 数值型外生·同刻历史流量 | NYCMng 到 CHINng 的网络流量 | 0.06%  |
| `NYCMng_DNVRng**` | 数值型外生·同刻历史流量 | NYCMng 到 DNVRng 的网络流量 | 0.06%  |
| `NYCMng_HSTNng**` | 数值型外生·同刻历史流量 | NYCMng 到 HSTNng 的网络流量 | 0.06%  |
| `NYCMng_IPLSng**` | 数值型外生·同刻历史流量 | NYCMng 到 IPLSng 的网络流量 | 0.07%  |
| `NYCMng_KSCYng**` | 数值型外生·同刻历史流量 | NYCMng 到 KSCYng 的网络流量 | 0.26%  |
| `NYCMng_LOSAng**` | 数值型外生·同刻历史流量 | NYCMng 到 LOSAng 的网络流量 | 0.06%  |
| `NYCMng_SNVAng**` | 数值型外生·同刻历史流量 | NYCMng 到 SNVAng 的网络流量 | 0.06%  |
| `NYCMng_STTLng**` | 数值型外生·同刻历史流量 | NYCMng 到 STTLng 的网络流量 | 0.07%  |
| `NYCMng_WASHng**` | 数值型外生·同刻历史流量 | NYCMng 到 WASHng 的网络流量 | 0.06%  |
| `SNVAng_ATLAng**` | 数值型外生·同刻历史流量 | SNVAng 到 ATLAng 的网络流量 | 9.12%  |
| `SNVAng_NYCMng**` | 数值型外生·同刻历史流量 | SNVAng 到 NYCMng 的网络流量 | 2.31%  |
| `SNVAng_STTLng**` | 数值型外生·同刻历史流量 | SNVAng 到 STTLng 的网络流量 | 0.003% |
| `STTLng_ATLAng**` | 数值型外生·同刻历史流量 | STTLng 到 ATLAng 的网络流量 | 0%     |
| `STTLng_CHINng**` | 数值型外生·同刻历史流量 | STTLng 到 CHINng 的网络流量 | 0%     |
| `STTLng_DNVRng**` | 数值型外生·同刻历史流量 | STTLng 到 DNVRng 的网络流量 | 0%     |
| `STTLng_HSTNng**` | 数值型外生·同刻历史流量 | STTLng 到 HSTNng 的网络流量 | 0%     |
| `STTLng_IPLSng**` | 数值型外生·同刻历史流量 | STTLng 到 IPLSng 的网络流量 | 0%     |
| `STTLng_KSCYng**` | 数值型外生·同刻历史流量 | STTLng 到 KSCYng 的网络流量 | 0.03%  |
| `STTLng_LOSAng**` | 数值型外生·同刻历史流量 | STTLng 到 LOSAng 的网络流量 | 0%     |
| `STTLng_SNVAng**` | 数值型外生·同刻历史流量 | STTLng 到 SNVAng 的网络流量 | 0%     |
| `STTLng_WASHng**` | 数值型外生·同刻历史流量 | STTLng 到 WASHng 的网络流量 | 0%     |
| `WASHng_ATLAng**` | 数值型外生·同刻历史流量 | WASHng 到 ATLAng 的网络流量 | 0.003% |
| `WASHng_CHINng**` | 数值型外生·同刻历史流量 | WASHng 到 CHINng 的网络流量 | 0.003% |
| `WASHng_KSCYng**` | 数值型外生·同刻历史流量 | WASHng 到 KSCYng 的网络流量 | 0.08%  |
| `WASHng_NYCMng**` | 数值型外生·同刻历史流量 | WASHng 到 NYCMng 的网络流量 | 0.003% |
| `WASHng_STTLng**` | 数值型外生·同刻历史流量 | WASHng 到 STTLng 的网络流量 | 0.006% |

| 字段名                                     | 字段的种类         | 字段的含义简介                 | 字段的缺失率 |
| --------------------------------------- | ------------- | ----------------------- | ------ |
| `time_sin_24h`                          | 数值型外生·确定性时间编码 | 24 小时周期的正弦时间编码          | 0%     |
| `time_cos_24h`                          | 数值型外生·确定性时间编码 | 24 小时周期的余弦时间编码          | 0%     |
| `time_sin_168h`                         | 数值型外生·确定性时间编码 | 168 小时周期的正弦时间编码         | 0%     |
| `time_cos_168h`                         | 数值型外生·确定性时间编码 | 168 小时周期的余弦时间编码         | 0%     |
| `day_of_month`                          | 数值型外生·确定性时间编码 | 月份中的日期序号                | 0%     |
| `is_daylight_saving_time_most_us_nodes` | 数值型外生·确定性时间编码 | 除 IPLSng 外节点在该时刻是否处于夏令时 | 0%     |
| `is_daylight_saving_time_IPLSng`        | 数值型外生·确定性时间编码 | IPLSng 节点在该时刻是否处于夏令时    | 0%     |

| 字段名                            | 字段的种类      | 字段的含义简介           | 字段的缺失率 |
| ------------------------------ | ---------- | ----------------- | ------ |
| `weather_STTLng_temperature_c` | 数值型外生·历史气象 | STTLng 节点代理站的气温   | 0%     |
| `weather_STTLng_dew_point_c`   | 数值型外生·历史气象 | STTLng 节点代理站的露点温度 | 0%     |
| `weather_STTLng_visibility_m`  | 数值型外生·历史气象 | STTLng 节点代理站的能见度  | 0%     |
| `weather_NYCMng_temperature_c` | 数值型外生·历史气象 | NYCMng 节点代理站的气温   | 0%     |
| `weather_NYCMng_dew_point_c`   | 数值型外生·历史气象 | NYCMng 节点代理站的露点温度 | 0%     |
| `weather_NYCMng_visibility_m`  | 数值型外生·历史气象 | NYCMng 节点代理站的能见度  | 0%     |

| 字段名                            | 字段的种类     | 字段的含义简介              | 字段的缺失率          |
| ------------------------------ | --------- | -------------------- | --------------- |
| `is_federal_holiday`           | 0/1 型外部事件 | 当前时间是否发生联邦节假日        | 0%              |
| `federal_holiday_name`         | 文本型外部事件   | 当前时间发生的联邦节假日具体名称     | 0%（结构空白 97.30%） |
| `is_major_media_sport_event`   | 0/1 型外部事件 | 当前时间是否发生大型媒体/体育事件    | 0%              |
| `major_media_sport_event_name` | 文本型外部事件   | 当前时间发生的大型媒体/体育事件具体名称 | 0%（结构空白 63.06%） |
| `is_academic_event`            | 0/1 型外部事件 | 当前时间是否发生学术日历事件       | 0%              |
| `academic_event_name`          | 文本型外部事件   | 当前时间发生的学术日历事件具体名称    | 0%              |
| `is_security_event**`            | 0/1 型外部事件 | 当前时间是否发生网络安全事件       | 0%              |
| `security_event_name**`          | 文本型外部事件   | 当前时间发生的网络安全事件具体名称    | 0%（结构空白 97.30%） |
| `is_special_federal_closure**`   | 0/1 型外部事件 | 当前时间是否发生特殊联邦停工       | 0%              |
| `special_federal_closure_name**` | 文本型外部事件   | 当前时间发生的特殊联邦停工具体名称    | 0%（结构空白 99.10%） |
| `is_extreme_weather_event`     | 0/1 型外部事件 | 当前时间是否发生极端天气事件       | 0%              |
| `extreme_weather_event_name`   | 文本型外部事件   | 当前时间发生的极端天气事件具体名称    | 0%（结构空白 98.31%） |

