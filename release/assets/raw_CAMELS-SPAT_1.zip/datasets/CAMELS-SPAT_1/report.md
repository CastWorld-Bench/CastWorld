# CAMELS-SPAT_1

Released source series. See the dataset metadata for frequency, target, and chronological splits.

## Field definitions

| 字段名                       | 字段的种类   | 字段的含义简介                | 字段的缺失率 | 冻结评测权限 |
| ------------------------- | ------- | ---------------------- | ------ | --- |
| `timestamp`               | 时间/截止时点 | 每日自然日日期，统一设置为当天 00:00。 | 0%     | 时间索引 |
| `target_downstream_q_obs` | 待预测值    | 下游场站的日平均观测流量；缺失值保持为空。  | 0%     | 历史输入；未来仅评分 |

| 字段名                       | 字段的种类            | 字段的含义简介             | 字段的缺失率 | 冻结评测权限 |
| ------------------------- | ---------------- | ------------------- | ------ | --- |
| `downstream__daymet_prcp` | 数值型外生·日级 forcing | Daymet 流域平均日降水量。    | 0%     | 历史与许可未来 |
| `downstream__daymet_tmax` | 数值型外生·日级 forcing | Daymet 流域平均日最高气温。   | 0%     | 历史与许可未来 |
| `downstream__daymet_tmin` | 数值型外生·日级 forcing | Daymet 流域平均日最低气温。   | 0%     | 历史与许可未来 |
| `downstream__daymet_srad` | 数值型外生·日级 forcing | Daymet 流域平均日太阳短波辐射。 | 0%     | 历史与许可未来 |
| `downstream__daymet_vp`   | 数值型外生·日级 forcing | Daymet 流域平均日水汽压。    | 0%     | 历史与许可未来 |
| `downstream__daymet_dayl` | 数值型外生·日级 forcing | Daymet 流域平均日照时长。    | 0%     | 历史与许可未来 |
| `downstream__daymet_pet`  | 数值型外生·日级 forcing | Daymet 流域平均日潜在蒸散发。  | 0%     | 历史与许可未来 |
| `upstream_1__daymet_prcp` | 数值型外生·日级 forcing | Daymet 流域平均日降水量。    | 0%     | 历史与许可未来 |
| `upstream_1__daymet_tmax` | 数值型外生·日级 forcing | Daymet 流域平均日最高气温。   | 0%     | 历史与许可未来 |
| `upstream_1__daymet_tmin` | 数值型外生·日级 forcing | Daymet 流域平均日最低气温。   | 0%     | 历史与许可未来 |
| `upstream_1__daymet_srad` | 数值型外生·日级 forcing | Daymet 流域平均日太阳短波辐射。 | 0%     | 历史与许可未来 |
| `upstream_1__daymet_vp`   | 数值型外生·日级 forcing | Daymet 流域平均日水汽压。    | 0%     | 历史与许可未来 |
| `upstream_1__daymet_dayl` | 数值型外生·日级 forcing | Daymet 流域平均日照时长。    | 0%     | 历史与许可未来 |
| `upstream_1__daymet_pet`  | 数值型外生·日级 forcing | Daymet 流域平均日潜在蒸散发。  | 0%     | 历史与许可未来 |
| `upstream_2__daymet_prcp` | 数值型外生·日级 forcing | Daymet 流域平均日降水量。    | 0%     | 历史与许可未来 |
| `upstream_2__daymet_tmax` | 数值型外生·日级 forcing | Daymet 流域平均日最高气温。   | 0%     | 历史与许可未来 |
| `upstream_2__daymet_tmin` | 数值型外生·日级 forcing | Daymet 流域平均日最低气温。   | 0%     | 历史与许可未来 |
| `upstream_2__daymet_srad` | 数值型外生·日级 forcing | Daymet 流域平均日太阳短波辐射。 | 0%     | 历史与许可未来 |
| `upstream_2__daymet_vp`   | 数值型外生·日级 forcing | Daymet 流域平均日水汽压。    | 0%     | 历史与许可未来 |
| `upstream_2__daymet_dayl` | 数值型外生·日级 forcing | Daymet 流域平均日照时长。    | 0%     | 历史与许可未来 |
| `upstream_2__daymet_pet`  | 数值型外生·日级 forcing | Daymet 流域平均日潜在蒸散发。  | 0%     | 历史与许可未来 |

| 字段名                                       | 字段的种类          | 字段的含义简介                                      | 字段的缺失率 | 冻结评测权限 |
| ----------------------------------------- | -------------- | -------------------------------------------- | ------ | --- |
| `downstream__eccc_mean_temperature_c`     | 数值型外生·同日观测/派生量 | ECCC 日平均气温（°C）。                              | 12.38% | 历史与许可未来 |
| `downstream__eccc_min_temperature_c`      | 数值型外生·同日观测/派生量 | ECCC 日最低气温（°C）。                              | 11.90% | 历史与许可未来 |
| `downstream__eccc_max_temperature_c`      | 数值型外生·同日观测/派生量 | ECCC 日最高气温（°C）。                              | 11.99% | 历史与许可未来 |
| `downstream__eccc_total_precipitation_mm` | 数值型外生·同日观测/派生量 | ECCC 日总降水量（mm），包括雨和雪。                        | 11.60% | 历史与许可未来 |
| `downstream__eccc_total_rain_mm`          | 数值型外生·同日观测/派生量 | ECCC 日总降雨量（mm）。                              | 11.58% | 历史与许可未来 |
| `downstream__eccc_total_snow_cm`          | 数值型外生·同日观测/派生量 | ECCC 日总降雪量（cm）。                              | 11.32% | 历史与许可未来 |
| `downstream__eccc_precip_3d_mm`           | 数值型外生·同日观测/派生量 | 当前日及前 2 日的 3 日累计降水量（mm）；只有窗口内 3 天均有降水记录时才输出。 | 15.53% | 历史与许可未来 |
| `downstream__eccc_dry_streak_days`        | 数值型外生·同日观测/派生量 | 截至当前日连续总降水量为 0 的天数；降水缺失时为空，出现降水后重新计数。        | 11.60% | 历史与许可未来 |

| 字段名                 | 字段的种类        | 字段的含义简介                         | 字段的缺失率 | 冻结评测权限 |
| ------------------- | ------------ | ------------------------------- | ------ | --- |
| `upstream_1__q_obs*` | 数值型外生·同日观测流量 | 上游场站同一自然日的观测流量；属于同期对齐，不表示提前量预测。 | 0%     | 仅历史 |
| `upstream_2__q_obs*` | 数值型外生·同日观测流量 | 上游场站同一自然日的观测流量；属于同期对齐，不表示提前量预测。 | 0%     | 仅历史 |

| 字段名                                              | 字段的种类     | 字段的含义简介                                        | 字段的缺失率             | 冻结评测权限 |
| ------------------------------------------------ | --------- | ---------------------------------------------- | ------------------ | --- |
| `downstream__eccc_dry_day_flag`                  | 0/1 型外部事件 | 当前日总降水量等于 0；降水缺失时为空。                           | 11.60%             | 历史与许可未来 |
| `downstream__eccc_heavy_precipitation_25mm_flag` | 0/1 型外部事件 | 当前日总降水量达到 25 mm 的候选强降水标志。                      | 11.60%             | 历史与许可未来 |
| `downstream__eccc_freeze_thaw_flag`              | 0/1 型外部事件 | 当前日日最低气温不高于 0°C 且日最高气温高于 0°C 的冻融转换标志。          | 12.38%             | 历史与许可未来 |
| `event__wildfire_count**`                          | 计数型外部事件   | 当前日期在对应网络范围内处于活动状态的野火事件数量。                     | 0%                 | 仅历史 |
| `event__regional_disaster_count**`                 | 计数型外部事件   | 当前日期在对应网络范围内处于活动状态的区域灾害事件数量。                   | 0%                 | 仅历史 |
| `event__rfc_advisory_count`                      | 计数型外部事件   | 当前日期在对应网络范围内处于活动状态的BC 河流预报中心公告或预警事件数量。         | 0%                 | 历史与许可未来 |
| `event__rfc_advisory_low_confidence_count`       | 计数型外部事件   | 当前日期在对应网络范围内处于活动状态且匹配置信度为低的BC 河流预报中心公告或预警事件数量。 | 0%                 | 历史与许可未来 |
| `event__wildfire_active**`                         | 0/1 型外部事件 | 当前日期是否至少有一个对应网络范围内活动的野火事件，1 表示有，0 表示没有。        | 0%                 | 仅历史 |
| `event__wildfire_severities**`                     | 文本型外部事件   | 当前日期活动野火事件的严重程度标签，多个标签以 ` \|\| ` 连接。           | 0.34%（结构空白 98.40%） | 仅历史 |

