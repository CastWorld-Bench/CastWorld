# CAMELS-SPAT_2

Released source series. See the dataset metadata for frequency, target, and chronological splits.

## Field definitions

| 字段名 | 字段的种类 | 字段的含义简介 | 字段的缺失率 |
| --- | --- | --- | --- |
| `timestamp` | 时间/截止时点 | 每日自然日日期，统一设置为当天 00:00。 | 0% |
| `target_downstream_q_obs` | 待预测值 | 下游场站的日平均观测流量；缺失值保持为空。 | 2.57% |

| 字段名 | 字段的种类 | 字段的含义简介 | 字段的缺失率 |
| --- | --- | --- | --- |
| `downstream__daymet_prcp` | 数值型外生·日级 forcing | Daymet 流域平均日降水量。 | 0% |
| `downstream__daymet_tmax` | 数值型外生·日级 forcing | Daymet 流域平均日最高气温。 | 0% |
| `downstream__daymet_tmin` | 数值型外生·日级 forcing | Daymet 流域平均日最低气温。 | 0% |
| `downstream__daymet_srad` | 数值型外生·日级 forcing | Daymet 流域平均日太阳短波辐射。 | 0% |
| `downstream__daymet_vp` | 数值型外生·日级 forcing | Daymet 流域平均日水汽压。 | 0% |
| `downstream__daymet_dayl` | 数值型外生·日级 forcing | Daymet 流域平均日照时长。 | 0% |
| `downstream__daymet_pet` | 数值型外生·日级 forcing | Daymet 流域平均日潜在蒸散发。 | 0% |
| `upstream_1__daymet_prcp` | 数值型外生·日级 forcing | Daymet 流域平均日降水量。 | 0% |
| `upstream_1__daymet_tmax` | 数值型外生·日级 forcing | Daymet 流域平均日最高气温。 | 0% |
| `upstream_1__daymet_tmin` | 数值型外生·日级 forcing | Daymet 流域平均日最低气温。 | 0% |
| `upstream_1__daymet_srad` | 数值型外生·日级 forcing | Daymet 流域平均日太阳短波辐射。 | 0% |
| `upstream_1__daymet_vp` | 数值型外生·日级 forcing | Daymet 流域平均日水汽压。 | 0% |
| `upstream_1__daymet_dayl` | 数值型外生·日级 forcing | Daymet 流域平均日照时长。 | 0% |
| `upstream_1__daymet_pet` | 数值型外生·日级 forcing | Daymet 流域平均日潜在蒸散发。 | 0% |
| `upstream_2__daymet_prcp` | 数值型外生·日级 forcing | Daymet 流域平均日降水量。 | 0% |
| `upstream_2__daymet_tmax` | 数值型外生·日级 forcing | Daymet 流域平均日最高气温。 | 0% |
| `upstream_2__daymet_tmin` | 数值型外生·日级 forcing | Daymet 流域平均日最低气温。 | 0% |
| `upstream_2__daymet_srad` | 数值型外生·日级 forcing | Daymet 流域平均日太阳短波辐射。 | 0% |
| `upstream_2__daymet_vp` | 数值型外生·日级 forcing | Daymet 流域平均日水汽压。 | 0% |
| `upstream_2__daymet_dayl` | 数值型外生·日级 forcing | Daymet 流域平均日照时长。 | 0% |
| `upstream_2__daymet_pet` | 数值型外生·日级 forcing | Daymet 流域平均日潜在蒸散发。 | 0% |

| 字段名 | 字段的种类 | 字段的含义简介 | 字段的缺失率 |
| --- | --- | --- | --- |
| `upstream_1__q_obs*` | 数值型外生·同日观测流量 | 上游场站同一自然日的观测流量；属于同期对齐，不表示提前量预测。 | 1.06% |
| `upstream_2__q_obs*` | 数值型外生·同日观测流量 | 上游场站同一自然日的观测流量；属于同期对齐，不表示提前量预测。 | 0% |

| 字段名 | 字段的种类 | 字段的含义简介 | 字段的缺失率 |
| --- | --- | --- | --- |
| `event__wildfire_count**` | 计数型外部事件 | 当前日期在对应网络范围内处于活动状态的野火事件数量。 | 0% |
| `event__regional_disaster_count**` | 计数型外部事件 | 当前日期在对应网络范围内处于活动状态的区域灾害事件数量。 | 0% |
| `event__rfc_advisory_count` | 计数型外部事件 | 当前日期在对应网络范围内处于活动状态的BC 河流预报中心公告或预警事件数量。 | 0% |
| `event__wildfire_active**` | 0/1 型外部事件 | 当前日期是否至少有一个对应网络范围内活动的野火事件，1 表示有，0 表示没有。 | 0% |
| `event__wildfire_severities**` | 文本型外部事件 | 当前日期活动野火事件的严重程度标签，多个标签以 ` \|\| ` 连接。 | 0.81%（结构空白 94.95%） |

