# MotorOil-GR-TI824

Released source series. See the dataset metadata for frequency, target, and chronological splits.

## Field definitions

| 字段名 | 字段种类 | 字段含义 | 缺失率 |
| --- | --- | --- | --- |
| `Timestamp` |  | 采样日期与时刻；时区未知 | 0% |
| `Temperature_TI824` |  | 温度测点TI824；待预测变量 | 0% |

| 字段名 | 字段种类 | 字段含义 | 缺失率 |
| --- | --- | --- | --- |
| `AxialDisplacement_ZI800BA**` | 数值型外生变量 | 轴向位移测点ZI800BA | 0% |
| `AxialDisplacement_ZI800BB**` | 数值型外生变量 | 轴向位移测点ZI800BB | 0% |
| `AxialDisplacement_ZI801BA**` | 数值型外生变量 | 轴向位移测点ZI801BA | 0% |
| `AxialDisplacement_ZI801BB**` | 数值型外生变量 | 轴向位移测点ZI801BB | 0% |
| `Pressure_PI808**` | 数值型外生变量 | 压力测点PI808 | 0% |
| `Pressure_PI823**` | 数值型外生变量 | 压力测点PI823 | 0% |
| `Pressure_PI870**` | 数值型外生变量 | 压力测点PI870 | 0% |
| `Pressure_PI845**` | 数值型外生变量 | 压力测点PI845 | 0% |
| `UnconfirmedDifferentialPressure_PDI853**` | 数值型外生变量 | 具体含义未知；按命名惯例推测为压差，未确认 | 0% |
| `Temperature_TI821**` | 数值型外生变量 | 温度测点TI821 | 0% |
| `Temperature_TI822**` | 数值型外生变量 | 温度测点TI822 | 0% |
| `Temperature_TI827**` | 数值型外生变量 | 温度测点TI827 | 0% |
| `Temperature_TI828**` | 数值型外生变量 | 温度测点TI828 | 0% |
| `Temperature_TI829**` | 数值型外生变量 | 温度测点TI829 | 0% |
| `Temperature_TI830**` | 数值型外生变量 | 温度测点TI830 | 0% |
| `Temperature_TI831**` | 数值型外生变量 | 温度测点TI831 | 0% |
| `Temperature_TI832**` | 数值型外生变量 | 温度测点TI832 | 0% |
| `Temperature_TI836**` | 数值型外生变量 | 温度测点TI836 | 0% |
| `Temperature_TI834**` | 数值型外生变量 | 温度测点TI834 | 0% |
| `UnknownSensor_XI821BX**` | 数值型外生变量 | 含义未知 | 0% |
| `UnknownSensor_XI822BY**` | 数值型外生变量 | 含义未知 | 0% |
| `UnknownSensor_XI823BX**` | 数值型外生变量 | 含义未知 | 0% |
| `UnknownSensor_XI824BX**` | 数值型外生变量 | 含义未知 | 0% |
| `RotationalSpeed_SI865R**` | 数值型外生变量 | 转速测点SI865R | 0% |

