# NYC-311

Released source series. See the dataset metadata for frequency, target, and chronological splits.

## Field definitions

| 字段名 | 字段种类 | 含义 | 缺失率 |
|---|---|---|---|
| `date` | 时间/截止时点 | 纽约当地日期；全表唯一主键和连接键 | 0% |
| `requests` | 待预测值 | 全市当天 311 服务请求总量，预测目标 | 0% |

| 字段名 | 字段种类 | 含义 | 缺失率 |
|---|---|---|---|
| `day_of_week` | 数值型外生·确定性数值 | 星期编码，0 表示星期一，6 表示星期日 | 0% |
| `season` | 数值型外生·确定性数值 | `winter`、`spring`、`summer` 或 `autumn` | 0% |
| `apparent_temperature_max_c` | 数值型外生·历史天气 | 日最高体感温度 | 0% |
| `apparent_temperature_min_c` | 数值型外生·历史天气 | 日最低体感温度 | 0% |
| `apparent_temperature_mean_c` | 数值型外生·历史天气 | 日平均体感温度 | 0% |
| `precipitation_sum_mm` | 数值型外生·历史天气 | 日总降水量 | 0% |
| `rain_sum_mm` | 数值型外生·历史天气 | 日总降雨量 | 0% |
| `precipitation_hours` | 数值型外生·历史天气 | 当日有降水的小时数 | 0% |
| `wind_speed_10m_max_kmh` | 数值型外生·历史天气 | 10 米高度日最大风速 | 0% |
| `wind_gusts_10m_max_kmh` | 数值型外生·历史天气 | 日最大阵风 | 0% |
| `cooling_degree_days_f` | 数值型外生·历史天气 | 制冷度日，按 `max(0, 平均华氏温度−65)` 计算 | 0% |

| 字段名 | 字段种类 | 含义 | 缺失率 |
|---|---|---|---|
| `is_weekend` | 0/1 型外部事件 | 是否周末 | 0% |
| `is_us_federal_holiday` | 0/1 型外部事件 | 是否美国联邦节假日 | 0% |
| `holiday_name` | 文本型外部事件 | 节假日名称；非节假日为空，属于结构性空值 | 0%（结构空白 97.46%） |
| `is_heat_season` | 0/1 型外部事件 | 是否纽约供暖季（10 月 1 日至次年 5 月 31 日） | 0% |
| `freeze_thaw_flag` | 0/1 型外部事件 | 当日最低温 ≤ 0°C 且最高温 ≥ 0°C | 0% |
| `heavy_precipitation_flag` | 0/1 型外部事件 | 日降水量达到 25 mm 及以上 | 0% |
| `snow_flag` | 0/1 型外部事件 | 日降雪量达到 2.5 cm 及以上 | 0% |
| `high_wind_flag` | 0/1 型外部事件 | 最大阵风达到 50 km/h 及以上 | 0% |
| `event_count_sport` | 计数型外部事件 | 体育活动数 | 0% |
| `event_count_market` | 计数型外部事件 | 市场活动数 | 0% |
| `event_count_block_party` | 计数型外部事件 | 街区派对数 | 0% |
| `event_count_active_scheduled` | 计数型外部事件 | 原 event_count_active 在可见排期活动集合内的统计；保留原定义 | 0% |
| `event_count_starting_scheduled` | 计数型外部事件 | 原 event_count_starting 在可见排期活动集合内的统计；保留原定义 | 0% |
| `event_count_ending_scheduled` | 计数型外部事件 | 原 event_count_ending 在可见排期活动集合内的统计；保留原定义 | 0% |
| `event_active_hours_scheduled` | 强度型外部事件 | 原 event_active_hours 在可见排期活动集合内的统计；保留原定义 | 0% |
| `full_street_closure_count_scheduled` | 计数型外部事件 | 原 full_street_closure_count 在可见排期活动集合内的统计；保留原定义 | 0% |
| `partial_street_closure_count_scheduled` | 计数型外部事件 | 原 partial_street_closure_count 在可见排期活动集合内的统计；保留原定义 | 0% |
| `major_event_flag_scheduled` | 0/1 型外部事件 | 原 major_event_flag 在可见排期活动集合内的统计；保留原定义 | 0% |
| `event_active_borough_bronx_scheduled` | 计数型外部事件 | 原 event_active_borough_bronx 在可见排期活动集合内的统计；保留原定义 | 0% |
| `event_active_borough_brooklyn_scheduled` | 计数型外部事件 | 原 event_active_borough_brooklyn 在可见排期活动集合内的统计；保留原定义 | 0% |
| `event_active_borough_manhattan_scheduled` | 计数型外部事件 | 原 event_active_borough_manhattan 在可见排期活动集合内的统计；保留原定义 | 0% |
| `event_active_borough_queens_scheduled` | 计数型外部事件 | 原 event_active_borough_queens 在可见排期活动集合内的统计；保留原定义 | 0% |
| `event_active_borough_staten_island_scheduled` | 计数型外部事件 | 原 event_active_borough_staten_island 在可见排期活动集合内的统计；保留原定义 | 0% |
| `event_count_street_event_race` | 计数型外部事件 | 原 event_count_street_event 中的赛事记录数 | 0% |
| `event_count_street_event_festival` | 计数型外部事件 | 原 event_count_street_event 中的常规节庆记录数 | 0% |

| 字段名 | 字段种类 | 含义 | 缺失率 |
|---|---|---|---|
| `gas_incident_count**` | 计数型外部事件 | NYC Emergency Response 中天然气相关 `Utility-*` 事件的创建日数量 | 0% |
| `street_permits_issued**` | 计数型外部事件 | 道路施工许可在服务器端签发日的聚合数量 | 0% |
| `building_permits_issued_dob_now**` | 计数型外部事件 | DOB NOW 建筑许可批准/签发日聚合数量 | 0% |
| `building_permits_issued**` | 计数型外部事件 | DOB BIS 与 DOB NOW （纽约市楼宇局的两个系统）许可数量合计 | 0% |
| `event_count_active_other**` | 计数型外部事件 | 当天全纽约其他活动记录数，含游行、未确认活动及未纳入可见集合的记录 | 0% |
| `full_street_closure_count_other**` | 计数型外部事件 | 其他活动对应的全街封闭许可记录数 | 0% |
| `partial_street_closure_count_other**` | 计数型外部事件 | 其他活动对应的部分封闭/其他限制方式许可记录数 | 0% |

