# NYC-EMS

Released source series. See the dataset metadata for frequency, target, and chronological splits.

## Field definitions

| 字段名         | 字段种类    | 含义                        | 缺失率 | 冻结评测权限 |
| ----------- | ------- | ------------------------- | --- | --- |
| `date`      | 时间/截止时点 | 观测日期，统一为 YYYY-MM-DD。      | 0%  | 时间索引 |
| `incidents` | 待预测值    | NYC EMS 当日事件数量；本数据集的预测目标。 | 0%  | 历史输入；未来仅评分 |

| 字段名                             | 字段种类          | 含义                                | 缺失率   | 冻结评测权限 |
| ------------------------------- | ------------- | --------------------------------- | ----- | --- |
| `day_of_week`                   | 数值型外生·确定性日历编码 | 星期编码，Python weekday 口径：周一=0，周日=6。 | 0%    | 历史与许可未来 |
| `day_of_year`                   | 数值型外生·确定性日历编码 | 一年中的第几天。                          | 0%    | 历史与许可未来 |
| `season`                        | 数值型外生·确定性日历编码 | 季节：winter、spring、summer 或 autumn。 | 0%    | 历史与许可未来 |
| `day_of_year_cos`               | 数值型外生·确定性日历编码 | 一年周期的余弦编码。                        | 0%    | 历史与许可未来 |
| `temperature_2m_max_c`          | 数值型外生·历史天气    | 2米高度日最高气温（°C）。                    | 0%    | 历史与许可未来 |
| `temperature_2m_min_c`          | 数值型外生·历史天气    | 2米高度日最低气温（°C）。                    | 0%    | 历史与许可未来 |
| `temperature_2m_mean_c`         | 数值型外生·历史天气    | 2米高度日平均气温（°C）。                    | 0%    | 历史与许可未来 |
| `apparent_temperature_max_c`    | 数值型外生·历史天气    | 日最高体感温度（°C）。                      | 0%    | 历史与许可未来 |
| `apparent_temperature_min_c`    | 数值型外生·历史天气    | 日最低体感温度（°C）。                      | 0%    | 历史与许可未来 |
| `apparent_temperature_mean_c`   | 数值型外生·历史天气    | 日平均体感温度（°C）。                      | 0%    | 历史与许可未来 |
| `precipitation_sum_mm`          | 数值型外生·历史天气    | 日总降水量（mm）。                        | 0%    | 历史与许可未来 |
| `rain_sum_mm`                   | 数值型外生·历史天气    | 日降雨量（mm）。                         | 0%    | 历史与许可未来 |
| `snowfall_sum_cm`               | 数值型外生·历史天气    | 日降雪量（cm）。                         | 0%    | 历史与许可未来 |
| `precipitation_hours`           | 数值型外生·历史天气    | 有降水小时数。                           | 0%    | 历史与许可未来 |
| `wind_speed_10m_max_kmh`        | 数值型外生·历史天气    | 10米高度日最大风速（km/h）。                 | 0%    | 历史与许可未来 |
| `wind_gusts_10m_max_kmh`        | 数值型外生·历史天气    | 10米高度日最大阵风（km/h）。                 | 0%    | 历史与许可未来 |
| `relative_humidity_2m_mean_pct` | 数值型外生·历史天气    | 2米高度日平均相对湿度（%）。                   | 0%    | 历史与许可未来 |
| `dew_point_2m_mean_c`           | 数值型外生·历史天气    | 2米高度日平均露点温度（°C）。                  | 0%    | 历史与许可未来 |
| `surface_pressure_mean_hpa`     | 数值型外生·历史天气    | 日平均地面气压（hPa）。                     | 0%    | 历史与许可未来 |
| `heating_degree_days_f`         | 数值型外生·历史天气    | 采暖度日，按 65°F 基准计算。                 | 0%    | 历史与许可未来 |
| `cooling_degree_days_f`         | 数值型外生·历史天气    | 制冷度日，按 65°F 基准计算。                 | 0%    | 历史与许可未来 |
| `epa_aqi`                       | 数值型外生·历史观测    | EPA/AQS New York 都市区日 AQI。        | 0.20% | 历史与许可未来 |
| `epa_ozone_mean`                | 数值型外生·历史观测    | NYC 五区监测站臭氧日均值。                   | 0.22% | 历史与许可未来 |
| `epa_ozone_max`                 | 数值型外生·历史观测    | NYC 五区监测站臭氧日最大值。                  | 0.22% | 历史与许可未来 |
| `epa_pm25_88101_mean`           | 数值型外生·历史观测    | PM2.5 参数 88101 的日均值。              | 1.47% | 历史与许可未来 |
| `epa_pm25_88101_max`            | 数值型外生·历史观测    | PM2.5 参数 88101 的日最大值。             | 1.47% | 历史与许可未来 |
| `epa_pm25_88502_mean`           | 数值型外生·历史观测    | PM2.5 参数 88502 的日均值。              | 0.26% | 历史与许可未来 |
| `epa_pm25_88502_max`            | 数值型外生·历史观测    | PM2.5 参数 88502 的日最大值。             | 0.26% | 历史与许可未来 |
| `epa_no2_mean`                  | 数值型外生·历史观测    | 二氧化氮（NO₂）日均值。                     | 0.77% | 历史与许可未来 |
| `epa_no2_max`                   | 数值型外生·历史观测    | 二氧化氮（NO₂）日最大值。                    | 0.77% | 历史与许可未来 |
| `epa_co_mean`                   | 数值型外生·历史观测    | 一氧化碳（CO）日均值。                      | 0.20% | 历史与许可未来 |
| `epa_co_max`                    | 数值型外生·历史观测    | 一氧化碳（CO）日最大值。                     | 0.20% | 历史与许可未来 |
| `epa_so2_mean`                  | 数值型外生·历史观测    | 二氧化硫（SO₂）日均值。                     | 0.26% | 历史与许可未来 |
| `epa_so2_max`                   | 数值型外生·历史观测    | 二氧化硫（SO₂）日最大值。                    | 0.22% | 历史与许可未来 |

| 字段名                                            | 字段种类            | 含义                          | 缺失率                | 冻结评测权限 |
| ---------------------------------------------- | --------------- | --------------------------- | ------------------ | --- |
| `influenza_unspecified_lab_confirmed_weekly**` | 数值型外生·周度/历史发布数据 | NYC 五县每周实验室确诊、未细分型流感病例数。    | 5.18%（结构空白 85.69%） | 仅历史 |
| `influenza_lab_confirmed_weekly_total**`       | 数值型外生·周度/历史发布数据 | NYC 五县每周实验室确诊流感病例总数。        | 5.18%（结构空白 85.69%） | 仅历史 |
| `covid_hospital_patients_currently**`          | 数值型外生·周度/历史发布数据 | NYC 设施当前 COVID 住院患者数。       | 68.00%             | 仅历史 |
| `covid_hospital_admitted_due_to_covid**`       | 数值型外生·周度/历史发布数据 | 因 COVID 入院的患者数。             | 68.00%             | 仅历史 |
| `covid_hospital_admitted_not_due_to_covid**`   | 数值型外生·周度/历史发布数据 | 非因 COVID 入院但检测为 COVID 的患者数。 | 68.00%             | 仅历史 |
| `covid_hospital_icu_currently**`               | 数值型外生·周度/历史发布数据 | 当前 COVID ICU 患者数。           | 68.00%             | 仅历史 |

| 字段名                                          | 字段种类       | 含义                                                     | 缺失率             | 冻结评测权限 |
| -------------------------------------------- | ---------- | ------------------------------------------------------ | --------------- | --- |
| `is_weekend`                                 | 0/1 型外部事件  | 是否周末（1/0）。                                             | 0%              | 历史与许可未来 |
| `is_us_federal_holiday`                      | 0/1 型外部事件  | 是否美国联邦节假日（1/0）。                                        | 0%              | 历史与许可未来 |
| `holiday_name`                               | 文本型外部事件    | 节假日名称；非节假日为空。                                          | 0%（结构空白 97.43%） | 历史与许可未来 |
| `dst_transition`                             | 数值型外部事件    | 是否夏令时切换日（1/0）。                                         | 0%              | 历史与许可未来 |
| `freeze_thaw_flag`                           | 0/1 型外部事件  | 当日最低温≤0°C且最高温≥0°C的冻融标记。                                | 0%              | 历史与许可未来 |
| `heavy_precipitation_flag`                   | 0/1 型外部事件  | 日降水量达到 25 mm 的强降水标记。                                   | 0%              | 历史与许可未来 |
| `snow_flag`                                  | 0/1 型外部事件  | 日降雪量达到 2.5 cm 的降雪标记。                                   | 0%              | 历史与许可未来 |
| `high_wind_flag`                             | 0/1 型外部事件  | 日最大阵风达到 50 km/h 的大风标记。                                 | 0%              | 历史与许可未来 |
| `epa_aqi_category`                           | 等级/类别型外部事件 | AQI 类别。                                                | 0.20%           | 历史与许可未来 |
| `street_festival_count`                      | 计数型外部事件    | 街头节庆活动数量。                                              | 0%              | 历史与许可未来 |
| `athletic_race_count`                        | 计数型外部事件    | 体育赛事/路跑活动数量。                                           | 0%              | 历史与许可未来 |
| `health_fair_count`                          | 计数型外部事件    | 健康集市活动数量。                                              | 0%              | 历史与许可未来 |
| `block_party_count`                          | 计数型外部事件    | 街区派对活动数量。                                              | 0%              | 历史与许可未来 |
| `large_special_event_count`                  | 计数型外部事件    | 大型特殊活动数量。                                              | 0%              | 历史与许可未来 |
| `mass_event_count_scheduled`                 | 计数型外部事件    | 原 mass_event_count 在可见排期活动集合内的统计；保留原定义                 | 0%              | 历史与许可未来 |
| `mass_event_count_starting_scheduled`        | 计数型外部事件    | 原 mass_event_count_starting 在可见排期活动集合内的统计；保留原定义        | 0%              | 历史与许可未来 |
| `mass_event_count_ending_scheduled`          | 计数型外部事件    | 原 mass_event_count_ending 在可见排期活动集合内的统计；保留原定义          | 0%              | 历史与许可未来 |
| `mass_event_active_hours_scheduled`          | 强度型外部事件    | 原 mass_event_active_hours 在可见排期活动集合内的统计；保留原定义          | 0%              | 历史与许可未来 |
| `full_street_closure_count_scheduled`        | 计数型外部事件    | 原 full_street_closure_count 在可见排期活动集合内的统计；保留原定义        | 0%              | 历史与许可未来 |
| `partial_street_closure_count_scheduled`     | 计数型外部事件    | 原 partial_street_closure_count 在可见排期活动集合内的统计；保留原定义     | 0%              | 历史与许可未来 |
| `named_major_event_count_scheduled`          | 计数型外部事件    | 原 named_major_event_count 在可见排期活动集合内的统计；保留原定义          | 0%              | 历史与许可未来 |
| `named_major_event_flag_scheduled`           | 0/1 型外部事件  | 原 named_major_event_flag 在可见排期活动集合内的统计；保留原定义           | 0%              | 历史与许可未来 |
| `mass_event_borough_bronx_scheduled`         | 计数型外部事件    | 原 mass_event_borough_bronx 在可见排期活动集合内的统计；保留原定义         | 0%              | 历史与许可未来 |
| `mass_event_borough_brooklyn_scheduled`      | 计数型外部事件    | 原 mass_event_borough_brooklyn 在可见排期活动集合内的统计；保留原定义      | 0%              | 历史与许可未来 |
| `mass_event_borough_manhattan_scheduled`     | 计数型外部事件    | 原 mass_event_borough_manhattan 在可见排期活动集合内的统计；保留原定义     | 0%              | 历史与许可未来 |
| `mass_event_borough_queens_scheduled`        | 计数型外部事件    | 原 mass_event_borough_queens 在可见排期活动集合内的统计；保留原定义        | 0%              | 历史与许可未来 |
| `mass_event_borough_staten_island_scheduled` | 计数型外部事件    | 原 mass_event_borough_staten_island 在可见排期活动集合内的统计；保留原定义 | 0%              | 历史与许可未来 |
| `religious_event_count_sapo`                 | 计数型外部事件    | SAPO宗教活动（可见计划）                                         | 0%              | 历史与许可未来 |

| 字段名                                              | 字段种类    | 含义                                | 缺失率    | 冻结评测权限 |
| ------------------------------------------------ | ------- | --------------------------------- | ------ | --- |
| `motor_collision_count**`                        | 计数型外部事件 | NYPD 机动车碰撞事件数。                    | 0%     | 仅历史 |
| `motor_collision_persons_injured**`              | 计数型外部事件 | 碰撞涉及的受伤人数。                        | 0%     | 仅历史 |
| `motor_collision_pedestrians_injured**`          | 计数型外部事件 | 碰撞涉及的受伤行人数。                       | 0%     | 仅历史 |
| `motor_collision_cyclists_injured**`             | 计数型外部事件 | 碰撞涉及的受伤骑行者人数。                     | 0%     | 仅历史 |
| `motor_collision_cyclists_killed**`              | 计数型外部事件 | 碰撞涉及的死亡骑行者人数。                     | 0%     | 仅历史 |
| `motor_collision_motorists_injured**`            | 计数型外部事件 | 碰撞涉及的受伤机动车乘员人数。                   | 0%     | 仅历史 |
| `motor_collision_motorists_killed**`             | 计数型外部事件 | 碰撞涉及的死亡机动车乘员人数。                   | 0%     | 仅历史 |
| `motor_collision_bronx_count**`                  | 计数型外部事件 | Bronx 区机动车碰撞事件数。                  | 0%     | 仅历史 |
| `motor_collision_brooklyn_count**`               | 计数型外部事件 | Brooklyn 区机动车碰撞事件数。               | 0%     | 仅历史 |
| `motor_collision_manhattan_count**`              | 计数型外部事件 | Manhattan 区机动车碰撞事件数。              | 0%     | 仅历史 |
| `motor_collision_queens_count**`                 | 计数型外部事件 | Queens 区机动车碰撞事件数。                 | 0%     | 仅历史 |
| `fdny_fire_incident_count**`                     | 计数型外部事件 | FDNY 消防调度事件数（去重事件）。               | 16.92% | 仅历史 |
| `fdny_fire_engines_assigned_total**`             | 计数型外部事件 | 出动 Engine 单位数量合计。                 | 16.92% | 仅历史 |
| `fdny_fire_ladders_assigned_total**`             | 计数型外部事件 | 出动 Ladder 单位数量合计。                 | 16.92% | 仅历史 |
| `fdny_fire_other_units_assigned_total**`         | 计数型外部事件 | 出动其它消防单位数量合计。                     | 16.92% | 仅历史 |
| `fdny_fire_group_nonmedical_emergencies_count**` | 计数型外部事件 | FDNY 原始分类中的非医疗紧急事件数。              | 16.92% | 仅历史 |
| `fdny_fire_group_nonmedical_mfas_count**`        | 计数型外部事件 | FDNY 原始分类中的非医疗 MFAs 事件数。          | 16.92% | 仅历史 |
| `fdny_fire_group_nonstructural_fires_count**`    | 计数型外部事件 | FDNY 原始分类中的非结构性火灾事件数。             | 16.92% | 仅历史 |
| `fdny_fire_group_structural_fires_count**`       | 计数型外部事件 | FDNY 原始分类中的结构性火灾事件数。              | 16.92% | 仅历史 |
| `fdny_fire_bronx_count**`                        | 计数型外部事件 | Bronx 区 FDNY 调度事件数。               | 16.92% | 仅历史 |
| `fdny_fire_brooklyn_count**`                     | 计数型外部事件 | Brooklyn 区 FDNY 调度事件数。            | 16.92% | 仅历史 |
| `fdny_fire_manhattan_count**`                    | 计数型外部事件 | Manhattan 区 FDNY 调度事件数。           | 16.92% | 仅历史 |
| `fdny_fire_queens_count**`                       | 计数型外部事件 | Queens 区 FDNY 调度事件数。              | 16.92% | 仅历史 |
| `fdny_fire_staten_island_count**`                | 计数型外部事件 | Staten Island 区 FDNY 调度事件数。       | 16.92% | 仅历史 |
| `mass_event_count_other**`                       | 计数型外部事件 | 当天全纽约其他活动记录数，含游行、未确认活动及未纳入可见集合的记录 | 0%     | 仅历史 |
| `full_street_closure_count_other**`              | 计数型外部事件 | 其他活动对应的全街封闭许可记录数                  | 0%     | 仅历史 |
| `partial_street_closure_count_other**`           | 计数型外部事件 | 其他活动对应的部分封闭/其他限制方式许可记录数           | 0%     | 仅历史 |

| 字段名                                            | 字段种类    | 含义                            | 缺失率    | 冻结评测权限 |
| ---------------------------------------------- | ------- | ----------------------------- | ------ | --- |
| `fdny_fire_group_medical_emergencies_count***` | 计数型外部事件 | FDNY 原始分类中的医疗急救事件数。           | 16.92% | 仅历史 |
| `fdny_fire_group_medical_mfas_count***`        | 计数型外部事件 | FDNY 原始分类中的 Medical MFAs 事件数。 | 16.92% | 仅历史 |

