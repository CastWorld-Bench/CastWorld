# OPSD-DELU-Price

Released source series. See the dataset metadata for frequency, target, and chronological splits.

## Field definitions

| 序号  | 字段名                                          | 字段种类     | 可见性         | 含义                          | 单位/格式                 | 缺失数 |
| ---:| -------------------------------------------- | -------- | ----------- | --------------------------- | --------------------- | ---:|
| 1   | `utc_timestamp`                              | 时间戳      | 时间键或监督目标    | UTC 交付小时起点；本表唯一时间键。         | YYYY/MM/DD hh:mm（UTC） | 0   |
| 2   | `price_day_ahead_eur_per_mwh`                | 待预测变量    | 时间键或监督目标    | 目标变量：德卢竞价区日前电价原值。           | EUR/MWh               | 4   |
| 3   | `load_forecast_mw`                           | 数值型外生变量  | 未来可见        | 日前负荷预测；优先德卢值，缺失时使用德国全国值。    | MW                    | 0   |
| 4   | `neighbor_at_load_forecast_mw`               | 数值型外生变量  | 未来可见        | 奥地利对应交付小时的日前负荷预测。           | MW                    | 0   |
| 5   | `neighbor_be_load_forecast_mw`               | 数值型外生变量  | 未来可见        | 比利时对应交付小时的日前负荷预测。           | MW                    | 0   |
| 6   | `neighbor_ch_load_forecast_mw`               | 数值型外生变量  | 未来可见        | 瑞士对应交付小时的日前负荷预测。            | MW                    | 0   |
| 7   | `neighbor_cz_load_forecast_mw`               | 数值型外生变量  | 未来可见        | 捷克对应交付小时的日前负荷预测。            | MW                    | 0   |
| 8   | `neighbor_dk_1_load_forecast_mw`             | 数值型外生变量  | 未来可见        | 丹麦 DK1 区对应交付小时的日前负荷预测。      | MW                    | 0   |
| 9   | `neighbor_dk_2_load_forecast_mw`             | 数值型外生变量  | 未来可见        | 丹麦 DK2 区对应交付小时的日前负荷预测。      | MW                    | 0   |
| 10  | `neighbor_fr_load_forecast_mw`               | 数值型外生变量  | 未来可见        | 法国对应交付小时的日前负荷预测。            | MW                    | 0   |
| 11  | `neighbor_lu_load_forecast_mw`               | 数值型外生变量  | 未来可见        | 卢森堡对应交付小时的日前负荷预测。           | MW                    | 48  |
| 12  | `neighbor_nl_load_forecast_mw`               | 数值型外生变量  | 未来可见        | 荷兰对应交付小时的日前负荷预测。            | MW                    | 0   |
| 13  | `neighbor_pl_load_forecast_mw`               | 数值型外生变量  | 未来可见        | 波兰对应交付小时的日前负荷预测。            | MW                    | 0   |
| 14  | `gefs_north_temperature_c`                   | 数值型外生变量  | 未来可见        | 德国北部采样点的2 米气温预报。            | °C                    | 24  |
| 15  | `gefs_north_wind10_ms`                       | 数值型外生变量  | 未来可见        | 德国北部采样点的10 米风速预报。           | m/s                   | 24  |
| 16  | `gefs_north_cloud_pct`                       | 数值型外生变量  | 未来可见        | 德国北部采样点的总云量预报。              | %                     | 24  |
| 17  | `gefs_north_shortwave_wm2`                   | 数值型外生变量  | 未来可见        | 德国北部采样点的短波辐射通量预报。           | W/m²                  | 24  |
| 18  | `gefs_northeast_temperature_c`               | 数值型外生变量  | 未来可见        | 德国东北部采样点的2 米气温预报。           | °C                    | 24  |
| 19  | `gefs_northeast_wind10_ms`                   | 数值型外生变量  | 未来可见        | 德国东北部采样点的10 米风速预报。          | m/s                   | 24  |
| 20  | `gefs_northeast_cloud_pct`                   | 数值型外生变量  | 未来可见        | 德国东北部采样点的总云量预报。             | %                     | 24  |
| 21  | `gefs_northeast_shortwave_wm2`               | 数值型外生变量  | 未来可见        | 德国东北部采样点的短波辐射通量预报。          | W/m²                  | 24  |
| 22  | `gefs_east_temperature_c`                    | 数值型外生变量  | 未来可见        | 德国东部采样点的2 米气温预报。            | °C                    | 24  |
| 23  | `gefs_east_wind10_ms`                        | 数值型外生变量  | 未来可见        | 德国东部采样点的10 米风速预报。           | m/s                   | 24  |
| 24  | `gefs_east_cloud_pct`                        | 数值型外生变量  | 未来可见        | 德国东部采样点的总云量预报。              | %                     | 24  |
| 25  | `gefs_east_shortwave_wm2`                    | 数值型外生变量  | 未来可见        | 德国东部采样点的短波辐射通量预报。           | W/m²                  | 24  |
| 26  | `gefs_west_temperature_c`                    | 数值型外生变量  | 未来可见        | 德国西部采样点的2 米气温预报。            | °C                    | 24  |
| 27  | `gefs_west_wind10_ms`                        | 数值型外生变量  | 未来可见        | 德国西部采样点的10 米风速预报。           | m/s                   | 24  |
| 28  | `gefs_west_cloud_pct`                        | 数值型外生变量  | 未来可见        | 德国西部采样点的总云量预报。              | %                     | 24  |
| 29  | `gefs_west_shortwave_wm2`                    | 数值型外生变量  | 未来可见        | 德国西部采样点的短波辐射通量预报。           | W/m²                  | 24  |
| 30  | `gefs_central_temperature_c`                 | 数值型外生变量  | 未来可见        | 德国中部采样点的2 米气温预报。            | °C                    | 24  |
| 31  | `gefs_central_wind10_ms`                     | 数值型外生变量  | 未来可见        | 德国中部采样点的10 米风速预报。           | m/s                   | 24  |
| 32  | `gefs_central_cloud_pct`                     | 数值型外生变量  | 未来可见        | 德国中部采样点的总云量预报。              | %                     | 24  |
| 33  | `gefs_central_shortwave_wm2`                 | 数值型外生变量  | 未来可见        | 德国中部采样点的短波辐射通量预报。           | W/m²                  | 24  |
| 34  | `gefs_southwest_temperature_c`               | 数值型外生变量  | 未来可见        | 德国西南部采样点的2 米气温预报。           | °C                    | 24  |
| 35  | `gefs_southwest_wind10_ms`                   | 数值型外生变量  | 未来可见        | 德国西南部采样点的10 米风速预报。          | m/s                   | 24  |
| 36  | `gefs_southwest_cloud_pct`                   | 数值型外生变量  | 未来可见        | 德国西南部采样点的总云量预报。             | %                     | 24  |
| 37  | `gefs_southwest_shortwave_wm2`               | 数值型外生变量  | 未来可见        | 德国西南部采样点的短波辐射通量预报。          | W/m²                  | 24  |
| 38  | `gefs_southeast_temperature_c`               | 数值型外生变量  | 未来可见        | 德国东南部采样点的2 米气温预报。           | °C                    | 24  |
| 39  | `gefs_southeast_wind10_ms`                   | 数值型外生变量  | 未来可见        | 德国东南部采样点的10 米风速预报。          | m/s                   | 24  |
| 40  | `gefs_southeast_cloud_pct`                   | 数值型外生变量  | 未来可见        | 德国东南部采样点的总云量预报。             | %                     | 24  |
| 41  | `gefs_southeast_shortwave_wm2`               | 数值型外生变量  | 未来可见        | 德国东南部采样点的短波辐射通量预报。          | W/m²                  | 24  |
| 42  | `gefs_north_sea_temperature_c`               | 数值型外生变量  | 未来可见        | 北海附近采样点的2 米气温预报。            | °C                    | 24  |
| 43  | `gefs_north_sea_wind10_ms`                   | 数值型外生变量  | 未来可见        | 北海附近采样点的10 米风速预报。           | m/s                   | 24  |
| 44  | `gefs_north_sea_cloud_pct`                   | 数值型外生变量  | 未来可见        | 北海附近采样点的总云量预报。              | %                     | 24  |
| 45  | `gefs_north_sea_shortwave_wm2`               | 数值型外生变量  | 未来可见        | 北海附近采样点的短波辐射通量预报。           | W/m²                  | 24  |
| 46  | `gefs_land_mean_temperature_c`               | 数值型外生变量  | 未来可见        | 七个德国陆地点的2 米气温简单平均。          | °C                    | 24  |
| 47  | `gefs_land_mean_wind10_ms`                   | 数值型外生变量  | 未来可见        | 七个德国陆地点的10 米风速简单平均。         | m/s                   | 24  |
| 48  | `gefs_land_mean_cloud_pct`                   | 数值型外生变量  | 未来可见        | 七个德国陆地点的总云量简单平均。            | %                     | 24  |
| 49  | `gefs_land_mean_shortwave_wm2`               | 数值型外生变量  | 未来可见        | 七个德国陆地点的短波辐射通量简单平均。         | W/m²                  | 24  |
| 50  | `market_hour`                                | 数值型日历特征  | 未来可见        | 德国当地小时；秋季回拨时同一小时可出现两次。      | 0–23                  | 0   |
| 51  | `market_weekday`                             | 数值型日历特征  | 未来可见        | 德国当地星期，周一为 0、周日为 6。         | 0–6                   | 0   |
| 52  | `market_month`                               | 数值型日历特征  | 未来可见        | 德国当地月份。                     | 1–12                  | 0   |
| 53  | `utc_offset_minutes`                         | 数值型日历特征  | 未来可见        | 德国当地时间相对 UTC 的偏移。           | 分钟；通常为 60 或 120       | 0   |
| 54  | `is_weekend`                                 | 外生事件     | 未来可见        | 是否为周六或周日。                   | 1=是，0=否               | 0   |
| 55  | `public_holiday_state_count`                 | 外生事件     | 未来可见        | 当日全州适用的德国法定假日涉及州数。          | 个州                    | 0   |
| 56  | `local_public_holiday_state_count`           | 外生事件     | 未来可见        | 当日存在局部适用法定假日的州数。            | 个州                    | 0   |
| 57  | `public_holiday_bb`                          | 外生事件     | 未来可见        | 勃兰登堡当日是否为全州适用法定假日。          | 1=是，0=否               | 0   |
| 58  | `public_holiday_be`                          | 外生事件     | 未来可见        | 柏林当日是否为全州适用法定假日。            | 1=是，0=否               | 0   |
| 59  | `public_holiday_bw`                          | 外生事件     | 未来可见        | 巴登-符腾堡当日是否为全州适用法定假日。        | 1=是，0=否               | 0   |
| 60  | `public_holiday_hb`                          | 外生事件     | 未来可见        | 不来梅当日是否为全州适用法定假日。           | 1=是，0=否               | 0   |
| 61  | `public_holiday_he`                          | 外生事件     | 未来可见        | 黑森当日是否为全州适用法定假日。            | 1=是，0=否               | 0   |
| 62  | `public_holiday_hh`                          | 外生事件     | 未来可见        | 汉堡当日是否为全州适用法定假日。            | 1=是，0=否               | 0   |
| 63  | `public_holiday_mv`                          | 外生事件     | 未来可见        | 梅克伦堡-前波莫瑞当日是否为全州适用法定假日。     | 1=是，0=否               | 0   |
| 64  | `public_holiday_ni`                          | 外生事件     | 未来可见        | 下萨克森当日是否为全州适用法定假日。          | 1=是，0=否               | 0   |
| 65  | `public_holiday_nw`                          | 外生事件     | 未来可见        | 北莱茵-威斯特法伦当日是否为全州适用法定假日。     | 1=是，0=否               | 0   |
| 66  | `public_holiday_rp`                          | 外生事件     | 未来可见        | 莱茵兰-普法尔茨当日是否为全州适用法定假日。      | 1=是，0=否               | 0   |
| 67  | `public_holiday_sh`                          | 外生事件     | 未来可见        | 石勒苏益格-荷尔斯泰因当日是否为全州适用法定假日。   | 1=是，0=否               | 0   |
| 68  | `public_holiday_sl`                          | 外生事件     | 未来可见        | 萨尔当日是否为全州适用法定假日。            | 1=是，0=否               | 0   |
| 69  | `public_holiday_sn`                          | 外生事件     | 未来可见        | 萨克森当日是否为全州适用法定假日。           | 1=是，0=否               | 0   |
| 70  | `public_holiday_st`                          | 外生事件     | 未来可见        | 萨克森-安哈尔特当日是否为全州适用法定假日。      | 1=是，0=否               | 0   |
| 71  | `public_holiday_th`                          | 外生事件     | 未来可见        | 图林根当日是否为全州适用法定假日。           | 1=是，0=否               | 0   |
| 72  | `local_public_holiday_by`                    | 外生事件     | 未来可见        | 巴伐利亚当日是否有局部适用的法定假日。         | 1=是，0=否               | 0   |
| 73  | `local_public_holiday_sn`                    | 外生事件     | 未来可见        | 萨克森当日是否有局部适用的法定假日。          | 1=是，0=否               | 0   |
| 74  | `eua_last_auction_price_eur_per_tco2`        | 数值型外生变量  | 起点已知，可供输出使用 | 预测起点前最近一次 EUA 初级拍卖价格。       | EUR/tCO₂              | 0   |
| 75  | `eua_age_at_origin_days`                     | 数值型外生变量  | 起点已知，可供输出使用 | 预测起点距上一 EUA 拍卖日期的天数。        | 天                     | 0   |
| 76  | `eur_usd_last_reference`                     | 数值型外生变量  | 起点已知，可供输出使用 | 预测起点前最近的 ECB 欧元兑美元参考汇率。     | USD/EUR               | 0   |
| 77  | `de_load_actual_dminus2_mean_mw`             | 数值型外生变量  | 起点已知，可供输出使用 | 交付日前第 2 个当地日的德国实际负荷日均值。     | MW                    | 0   |
| 78  | `de_lu_solar_actual_dminus2_mean_mw`         | 数值型外生变量  | 起点已知，可供输出使用 | 交付日前第 2 个当地日的德卢太阳能实际发电日均值。  | MW                    | 0   |
| 79  | `de_lu_wind_onshore_actual_dminus2_mean_mw`  | 数值型外生变量  | 起点已知，可供输出使用 | 交付日前第 2 个当地日的德卢陆上风电实际发电日均值。 | MW                    | 0   |
| 80  | `de_lu_wind_offshore_actual_dminus2_mean_mw` | 数值型外生变量  | 起点已知，可供输出使用 | 交付日前第 2 个当地日的德卢海上风电实际发电日均值。 | MW                    | 0   |
| 81  | `price_lag_24h_utc`                          | 历史目标派生特征 | 起点已知，可供输出使用 | UTC 前 24 小时的德卢日前电价。         | EUR/MWh               | 4   |
| 82  | `price_lag_48h_utc`                          | 历史目标派生特征 | 起点已知，可供输出使用 | UTC 前 48 小时的德卢日前电价。         | EUR/MWh               | 4   |
| 83  | `price_lag_168h_utc`                         | 历史目标派生特征 | 起点已知，可供输出使用 | UTC 前 168 小时的德卢日前电价。        | EUR/MWh               | 4   |
| 84  | `DE_LU_load_actual_entsoe_transparency**`    | 数值型外生变量  | 仅历史         | 德卢竞价区同小时实际总负荷。              | MW；事后观测               | 20  |
| 85  | `DE_load_actual_entsoe_transparency**`       | 数值型外生变量  | 仅历史         | 德国同小时实际总负荷。                 | MW；事后观测               | 0   |
| 86  | `DE_LU_solar_generation_actual**`            | 数值型外生变量  | 仅历史         | 德卢竞价区同小时实际太阳能发电量。           | MW；事后观测               | 0   |
| 87  | `DE_LU_wind_generation_actual**`             | 数值型外生变量  | 仅历史         | 德卢竞价区同小时实际风电合计。             | MW；事后观测               | 0   |
| 88  | `DE_LU_wind_onshore_generation_actual**`     | 数值型外生变量  | 仅历史         | 德卢竞价区同小时实际陆上风电发电量。          | MW；事后观测               | 0   |
| 89  | `DE_LU_wind_offshore_generation_actual**`    | 数值型外生变量  | 仅历史         | 德卢竞价区同小时实际海上风电发电量。          | MW；事后观测               | 0   |
| 90  | `DE_solar_generation_actual**`               | 数值型外生变量  | 仅历史         | 德国同小时实际太阳能发电量。              | MW；事后观测               | 0   |
| 91  | `DE_wind_generation_actual**`                | 数值型外生变量  | 仅历史         | 德国同小时实际风电合计。                | MW；事后观测               | 0   |
| 92  | `DE_wind_onshore_generation_actual**`        | 数值型外生变量  | 仅历史         | 德国同小时实际陆上风电发电量。             | MW；事后观测               | 0   |
| 93  | `DE_wind_offshore_generation_actual**`       | 数值型外生变量  | 仅历史         | 德国同小时实际海上风电发电量。             | MW；事后观测               | 0   |

