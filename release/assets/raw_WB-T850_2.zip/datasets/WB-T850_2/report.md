# WB-T850_2

Released source series. See the dataset metadata for frequency, target, and chronological splits.

## Field definitions

| 字段名 | 字段的种类 | 字段的含义简介 | 字段的缺失率 |
| --- | --- | --- | --- |
| `timestamp` | 时间/截止时点 | 行的有效时间戳；UTC，格式 YYYY/MM/DD HH:MM。 | 0% |
| `t850_mean_k` | 待预测值 | 预测目标：城市局地 3×3 网格的余弦纬度加权 850 hPa 温度平均值。 | 0% |

| 字段名 | 字段的种类 | 字段的含义简介 | 字段的缺失率 |
| --- | --- | --- | --- |
| `wnpsh_z500_mean_gph` | 数值型外生·历史再分析/有效时刻值 | 西北太平洋副热带高压（WNPSH）远端区域的区域平均 500 hPa 位势高度。 | 0% |
| `wnpsh_z500_spatial_std_gph` | 数值型外生·历史再分析/有效时刻值 | 西北太平洋副热带高压（WNPSH）远端区域的区域内 500 hPa 位势高度的空间标准差，表示场的空间离散程度。 | 0% |
| `wnpsh_z500_max_gph` | 数值型外生·历史再分析/有效时刻值 | 西北太平洋副热带高压（WNPSH）远端区域的区域最大 500 hPa 位势高度。 | 0% |
| `wnpsh_z500_min_gph` | 数值型外生·历史再分析/有效时刻值 | 西北太平洋副热带高压（WNPSH）远端区域的区域最小 500 hPa 位势高度。 | 0% |
| `wnpsh_z500_zonal_slope_gph_per_deg` | 数值型外生·历史再分析/有效时刻值 | 西北太平洋副热带高压（WNPSH）远端区域的沿经度方向的 500 hPa 位势高度线性梯度。 | 0% |
| `wnpsh_z500_meridional_slope_gph_per_deg` | 数值型外生·历史再分析/有效时刻值 | 西北太平洋副热带高压（WNPSH）远端区域的沿纬度方向的 500 hPa 位势高度线性梯度。 | 0% |

| 字段名 | 字段的种类 | 字段的含义简介 | 字段的缺失率 |
| --- | --- | --- | --- |
| `oni_sst_c` | 数值型外生·低频/日度指数 | Niño 3.4 区域 ONI 对应的海温水平（季节三个月滑动平均）。 | 0% |
| `oni_anomaly_c` | 数值型外生·低频/日度指数 | Niño 3.4 海温相对于基准气候态的 ONI 异常。 | 0% |
| `ao_value` | 数值型外生·低频/日度指数 | 北极涛动（AO）月度指数，描述北半球环状环流异常。 | 0% |
| `meiv2_value` | 数值型外生·低频/日度指数 | Multivariate ENSO Index v2，多变量 ENSO 标准化指数。 | 0% |
| `scand_value` | 数值型外生·低频/日度指数 | 斯堪的纳维亚型（SCAND）月度环流指数，反映欧亚阻塞背景。 | 0% |
| `pdo_value` | 数值型外生·低频/日度指数 | 太平洋年代际振荡（PDO）月度指数。 | 0% |
| `dmi_had_value` | 数值型外生·低频/日度指数 | 基于 HadISST 的 Dipole Mode Index，作为印度洋偶极子（IOD）背景指标。 | 0% |
| `mjo_rmm1` | 数值型外生·低频/日度指数 | MJO RMM1 Wheeler–Hendon 多变量主成分坐标。 | 0% |
| `mjo_rmm2` | 数值型外生·低频/日度指数 | MJO RMM2 Wheeler–Hendon 多变量主成分坐标。 | 0% |
| `mjo_phase` | 类别型外生·MJO 位相 | 由 RMM1/RMM2 象限确定的 MJO 位相，1–8 为分类编码，不是连续量。 | 0% |

| 字段名 | 字段的种类 | 字段的含义简介 | 字段的缺失率 |
| --- | --- | --- | --- |
| `r2_soil_water_0_10cm` | 数值型外生·R2 再分析值 | NCEP/DOE R2 最近有效陆地点的 0–10 cm 土壤含水量。 | 0% |
| `r2_soil_water_10_200cm` | 数值型外生·R2 再分析值 | NCEP/DOE R2 最近有效陆地点的 10–200 cm 深层土壤含水量。 | 0% |
| `r2_snow_water_equivalent` | 数值型外生·R2 再分析值 | NCEP/DOE R2 雪水当量，表示积雪融化后对应的水层质量。 | 0% |
| `r2_skin_temperature_k` | 数值型外生·R2 再分析值 | NCEP/DOE R2 地表皮肤温度。 | 0% |
| `r2_air_temperature_2m_k` | 数值型外生·R2 再分析值 | NCEP/DOE R2 2 m 近地面空气温度。 | 0% |

| 字段名 | 字段的种类 | 字段的含义简介 | 字段的缺失率 |
| --- | --- | --- | --- |
| `tc_storm_count` | 计数型外部事件 | IBTrACS 轨迹在城市 2,000 km 范围内的热带气旋数量。 | 0% |
| `tc_min_distance_km` | 事件测量值 | 城市到 2,000 km 范围内最近热带气旋轨迹点的球面距离。 | 0% |
| `tc_max_wind_kt` | 事件测量值 | 对应事件窗口内记录的最大热带气旋风速。 | 0.57% |
| `tc_min_pressure_mb` | 事件测量值 | 对应事件窗口内记录的最低热带气旋中心气压。 | 0.56% |

