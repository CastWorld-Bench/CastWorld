# Wiki-EN-Views

Released source series. See the dataset metadata for frequency, target, and chronological splits.

## Field definitions

| 字段名           | 字段的种类   | 字段的含义简介                      | 字段的缺失率 |
| ------------- | ------- | ---------------------------- | ------ |
| `timestamp`   | 时间/截止时点 | 每日日期标签，格式 `YYYY/MM/DD 00:00` | 0%     |
| `views_daily` | 待预测值    | 英文维基全站该日 24 个小时访问量之和；待预测目标   | 0%     |

| 字段名                         | 字段的种类       | 字段的含义简介          | 字段的缺失率 |
| --------------------------- | ----------- | ---------------- | ------ |
| `calendar__weekday_monday0` | 数值型外生·确定性编码 | 星期序号，周一为 0、周日为 6 | 0%     |
| `calendar__is_weekend`      | 数值型外生·确定性编码 | 是否周末，1 为周六或周日    | 0%     |
| `calendar__iso_week`        | 数值型外生·确定性编码 | ISO 年内周序号        | 0%     |
| `calendar__month`           | 数值型外生·确定性编码 | 月份，1–12          | 0%     |
| `calendar__day_of_year`     | 数值型外生·确定性编码 | 年内第几天            | 0%     |
| `calendar__is_month_start`  | 数值型外生·确定性编码 | 是否月初             | 0%     |
| `calendar__is_month_end`    | 数值型外生·确定性编码 | 是否月末             | 0%     |
| `calendar__annual_sin`      | 数值型外生·确定性编码 | 年周期的正弦编码         | 0%     |
| `calendar__annual_cos`      | 数值型外生·确定性编码 | 年周期的余弦编码         | 0%     |

| 字段名                                                | 字段的种类        | 字段的含义简介                              | 字段的缺失率 |
| -------------------------------------------------- | ------------ | ------------------------------------ | ------ |
| `v4__gdelt_country_topic_record_count**`             | 数值型外生·日级历史汇总 | GDELT 当日带国家定位的新闻主题记录数                | 2.46%  |
| `v4__gdelt_country_count**`                          | 数值型外生·日级历史汇总 | GDELT 当日涉及的不同国家代码数                   | 2.46%  |
| `v4__gdelt_country_count_type_count**`               | 数值型外生·日级历史汇总 | GDELT 当日涉及的不同主题计数类型数（`COUNTTYPE`）    | 2.46%  |
| `v4__gdelt_country_topic_num_articles_sum**`         | 数值型外生·日级历史汇总 | GDELT 国家 × 主题记录的文章赋值数之和              | 2.46%  |
| `v4__gdelt_unlocated_topic_record_count**`           | 数值型外生·日级历史汇总 | GDELT 当日没有国家定位的主题记录数                 | 2.46%  |
| `v4__gdelt_unlocated_topic_num_articles_sum**`       | 数值型外生·日级历史汇总 | 上述无国家定位记录的文章赋值数之和                    | 2.46%  |
| `v4__noaa_tmax_ge_35c_obs_count`                   | 数值型外生·日级历史汇总 | NOAA GHCN-Daily 当日最高气温 ≥35°C 的站点观测条数 | 0%     |
| `v4__noaa_tmin_obs_count**`                          | 数值型外生·日级历史汇总 | NOAA 当日最低气温的站点观测条数                   | 0%     |
| `v4__noaa_prcp_obs_count**`                          | 数值型外生·日级历史汇总 | NOAA 当日降水量的站点观测条数                    | 0%     |
| `v4__who_daily_new_cases_reporting_country_count**`  | 数值型外生·日级历史汇总 | WHO 当日有 COVID-19 新增病例报告值的国家/地区数      | 0%     |
| `v4__who_daily_new_deaths_sum**`                     | 数值型外生·日级历史汇总 | WHO 当日各报告国家/地区 COVID-19 新增死亡数之和      | 0%     |
| `v4__who_daily_new_deaths_reporting_country_count**` | 数值型外生·日级历史汇总 | WHO 当日有新增死亡报告值的国家/地区数                | 0%     |
| `v4__ioda_affected_country_record_count**`           | 数值型外生·日级历史汇总 | IODA 当日网络中断摘要涉及的国家记录数                | 0%     |

| 字段名                                                                  | 字段的种类      | 字段的含义简介                     | 字段的缺失率 |
| -------------------------------------------------------------------- | ---------- | --------------------------- | ------ |
| `v4__nager_global_public_holiday_country_count`                      | 数值型外生·日级汇总 | Nager.Date 当日有全国性公众假期的支持国家数 | 0%     |
| `v4__nager_global_bank_holiday_country_count`                        | 数值型外生·日级汇总 | 当日有全国性银行假期的支持国家数            | 0%     |
| `v4__nager_regional_public_holiday_record_count`                     | 数值型外生·日级汇总 | 当日地区性公众假期记录数                | 0%     |
| `v4__nager_public_holiday_population_share_supported_countries_2020` | 数值型外生·日级汇总 | 全国公众假期涉及人口占已支持国家 2020 年人口之比 | 0%     |
| `v4__nager_bank_holiday_population_share_supported_countries_2020`   | 数值型外生·日级汇总 | 全国银行假期涉及人口占已支持国家 2020 年人口之比 | 0%     |

| 字段名                                          | 字段的种类   | 字段的含义简介                         | 字段的缺失率         |
| -------------------------------------------- | ------- | ------------------------------- | -------------- |
| `event__earthquake_m5plus_count**`             | 计数型外部事件 | USGS 当日全球震级 ≥5.0 的地震次数          | 0%             |
| `event__earthquake_m55plus_count**`            | 计数型外部事件 | USGS 当日全球震级 ≥5.5 的地震次数          | 0%             |
| `event__earthquake_m6plus_count**`             | 计数型外部事件 | USGS 当日全球震级 ≥6.0 的地震次数          | 0%             |
| `event__earthquake_m7plus_count**`             | 计数型外部事件 | USGS 当日全球震级 ≥7.0 的地震次数          | 0%             |
| `event__earthquake_max_magnitude**`            | 强度型外部事件 | 当日记录到的最大地震震级；无对应地震时为空           | 0%（结构空白 1.78%） |
| `event__gdacs_new_episode_count**`             | 计数型外部事件 | GDACS 当日开始的灾害事件期数               | 0%             |
| `event__gdacs_EQ_new_count**`                  | 计数型外部事件 | GDACS 当日新开始的地震灾害事件期数            | 0%             |
| `event__gdacs_TC_new_count**`                  | 计数型外部事件 | GDACS 当日新开始的热带气旋灾害事件期数          | 0%             |
| `event__gdacs_FL_new_count**`                  | 计数型外部事件 | GDACS 当日新开始的洪水灾害事件期数            | 0%             |
| `event__gdacs_VO_new_count**`                  | 计数型外部事件 | GDACS 当日新开始的火山灾害事件期数            | 0%             |
| `event__gdacs_orange_or_red_new_count**`       | 计数型外部事件 | GDACS 当日新开始、警报为橙色或红色的事件期数       | 0%             |
| `event__football_total_goals**`                | 计数型外部事件 | 五个欧洲顶级足球联赛当日比赛总进球数              | 0%             |
| `event__football_total_red_cards**`            | 计数型外部事件 | 上述比赛有记录的红牌总数                    | 0%             |
| `event__ifes_election_count`                 | 计数型外部事件 | IFES ElectionGuide 公开页中当日的选举条目数 | 0%             |
| `event__nobel_laureate_announcement_count`   | 计数型外部事件 | Nobel Prize API 中当日宣布的获奖者记录数    | 0%             |
| `event__ucdp_organized_violence_deaths_best**` | 计数型外部事件 | UCDP 当日有组织暴力事件的最佳死亡人数估计之和       | 0%             |

