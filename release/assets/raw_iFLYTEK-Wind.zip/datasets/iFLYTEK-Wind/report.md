# iFLYTEK-Wind

Released source series. See the dataset metadata for frequency, target, and chronological splits.

## Field definitions

| 字段名 | 字段的种类 | 字段的含义简介 | 字段的缺失率 |
| --- | --- | --- | --- |
| `date` | 时间/截止时点 | 15分钟时间戳。 | 0% |
| `real_power` | 待预测值 | 场站实际发电功率；原始缺失点已在本版本填补。 | 0% |

| 字段名 | 字段的种类 | 字段的含义简介 | 字段的缺失率 |
| --- | --- | --- | --- |
| `aerosol_optical_depth_fused` | 数值型外生·历史融合量 | 550 nm 全柱气溶胶光学厚度；衡量霾/气溶胶对太阳辐射的衰减 | 0% |
| `cloud_cover_fused` | 数值型外生·历史融合量 | 整层云量 | 0% |
| `cloud_cover_high_fused` | 数值型外生·历史融合量 | 高云云量 | 0% |
| `cloud_cover_low_fused` | 数值型外生·历史融合量 | 低云云量；对光伏遮挡和风场近地层天气较敏感 | 0% |
| `cloud_cover_mid_fused` | 数值型外生·历史融合量 | 中云云量 | 0% |
| `dew_point_2m_fused` | 数值型外生·历史融合量 | 2 m 露点温度；结合气温可表示凝结/结冰条件 | 0% |
| `direct_normal_irradiance_fused` | 数值型外生·历史融合量 | 直接法向辐照度 DNI；与组件入射角和光伏功率直接相关 | 0% |
| `direct_radiation_fused` | 数值型外生·历史融合量 | 水平面直接太阳辐射；赛题已有相近字段，此处为外部档案补充 | 0% |
| `dust_fused` | 数值型外生·历史融合量 | 近地面沙尘颗粒浓度代理；不等同于官方沙尘暴观测 | 0% |
| `pm10_fused` | 数值型外生·历史融合量 | 粒径小于 10 μm 的颗粒物浓度 | 0% |
| `pm2_5_fused` | 数值型外生·历史融合量 | 粒径小于 2.5 μm 的颗粒物浓度；细颗粒物/霾代理 | 0% |
| `precipitation_fused` | 数值型外生·历史融合量 | 过去一小时降水累计（雨+雪等） | 0% |
| `pressure_msl_fused` | 数值型外生·历史融合量 | 海平面气压；天气系统和大尺度环流代理 | 0% |
| `rain_fused` | 数值型外生·历史融合量 | 过去一小时液态降雨累计 | 0% |
| `relative_humidity_2m_fused` | 数值型外生·历史融合量 | 2 m 相对湿度 | 0% |
| `shortwave_radiation_fused` | 数值型外生·历史融合量 | 总短波太阳辐射 GHI | 0% |
| `soil_temperature_0_to_7cm_fused` | 数值型外生·历史融合量 | 0–7 cm 土壤温度；冻融状态代理 | 0% |
| `sunshine_duration_fused` | 数值型外生·历史融合量 | 过去一小时日照持续时间 | 0% |
| `surface_pressure_fused` | 数值型外生·历史融合量 | 地表气压；高程和天气系统状态代理 | 0% |
| `temperature_2m_fused` | 数值型外生·历史融合量 | 2 m 气温 | 0% |
| `vapour_pressure_deficit_fused` | 数值型外生·历史融合量 | 水汽压亏缺 VPD；空气干燥程度，影响蒸散/组件温度和沙尘悬浮 | 0% |
| `wind_gusts_10m_fused` | 数值型外生·历史融合量 | 10 m 阵风风速；极端风和风机保护动作代理 | 0% |
| `wind_speed_100m_fused` | 数值型外生·历史融合量 | 100 m 风速；独立于历史预报的档案补充 | 0% |
| `wind_speed_10m_fused` | 数值型外生·历史融合量 | 10 m 风速；近地层风场背景 | 0% |
| `dust_mean` | 数值型外生·历史融合量 | 九宫格区域近地面沙尘浓度均值；连续沙尘背景代理 | 0% |
| `snowfall_24h_sum` | 数值型外生·历史融合量 | 过去 24 小时降雪累计；已修正前向保持造成的四倍重复 | 0% |
| `icing_risk_score` | 数值型外生·历史融合量 | 温度、湿度/露点、降水/低能见度、风速四项结冰条件满足比例 | 0% |

| 字段名 | 字段的种类 | 字段的含义简介 | 字段的缺失率 |
| --- | --- | --- | --- |
| `hf_freezing_level_height_fused` | 数值型外生·历史预报 | 0°C 冻结层高度；可辅助判断降雪相态和结冰风险 | 0% |
| `hf_temperature_100m_fused` | 数值型外生·历史预报 | 100 m 高度温度 | 0% |
| `hf_temperature_120m_fused` | 数值型外生·历史预报 | 120 m 高度温度 | 0% |
| `hf_temperature_80m_fused` | 数值型外生·历史预报 | 80 m 高度温度；接近风机轮毂高度的热力背景 | 0% |
| `hf_visibility_fused` | 数值型外生·历史预报 | 历史预报能见度；低值可提示雾、降雪或沙尘影响 | 0% |
| `hf_wind_speed_100m_fused` | 数值型外生·历史预报 | 100 m 风速；高空风资源和大风/切出风险代理 | 0% |
| `hf_wind_speed_120m_fused` | 数值型外生·历史预报 | 120 m 风速；用于风切变/垂直风场特征 | 0% |
| `hf_wind_speed_80m_fused` | 数值型外生·历史预报 | 80 m 风速；与赛题同概念的外部历史预报补充 | 0% |

| 字段名 | 字段的种类 | 字段的含义简介 | 字段的缺失率 |
| --- | --- | --- | --- |
| `station_direct_radiation_fused` | 数值型外生·历史融合量 | 三站水平面直接辐射的稳健中心值 | 0% |
| `station_direct_radiation_spread` | 数值型外生·历史融合量 | 三站直接辐射空间标准差，反映局地云量/遮挡不均匀性 | 0% |
| `station_wind_speed_80m_vector_fused` | 数值型外生·历史融合量 | 按三站风速加权风矢量得到的80m合成风速 | 0% |
| `station_wind_speed_80m_energy_fused` | 数值型外生·历史融合量 | 三站风速立方平均的等效风速，贴近风机功率曲线的能量尺度 | 0% |
| `station_wind_direction_80m_fused` | 数值型外生·历史融合量 | 三站风向的圆形、风速加权合成角度 | 0% |
| `station_wind_direction_80m_sin` | 数值型外生·历史融合量 | 合成风向正弦编码，避免角度0/360断点 | 0% |
| `station_wind_direction_80m_cos` | 数值型外生·历史融合量 | 合成风向余弦编码，避免角度0/360断点 | 0% |
| `station_wind_direction_80m_resultant` | 数值型外生·历史融合量 | 三站风向一致性，1表示方向完全一致，0表示方向相互抵消 | 0% |
| `station_wind_speed_80m_spread` | 数值型外生·历史融合量 | 三站80m风速空间标准差 | 0% |
| `station_temperature_2m_fused` | 数值型外生·历史融合量 | 三站2m气温均值 | 0% |
| `station_temperature_2m_spread` | 数值型外生·历史融合量 | 三站2m气温空间标准差 | 0% |
| `station_relative_humidity_2m_fused` | 数值型外生·历史融合量 | 三站2m相对湿度均值 | 0% |
| `station_relative_humidity_2m_spread` | 数值型外生·历史融合量 | 三站2m相对湿度空间标准差 | 0% |
| `station_precipitation_fused` | 数值型外生·历史融合量 | 三站降水平均强度 | 0% |
| `station_precipitation_max` | 数值型外生·历史融合量 | 三站最大降水强度，保留局地降水事件 | 0% |
| `station_precipitation_spatial_std` | 数值型外生·历史融合量 | 三站降水空间标准差，描述降水局地性 | 0% |

| 字段名 | 字段的种类 | 字段的含义简介 | 字段的缺失率 |
| --- | --- | --- | --- |
| `weather_code_fused` | 等级/类别型外部事件 | WMO 天气现象代码；离散类别，区域统计列取众数 | 0% |
| `high_dust_proxy` | 0/1 型外部事件 | 6 小时平均 dust 达全期 p95 的高沙尘代理 | 0% |
| `station_precipitation_any` | 0/1 型外部事件 | 三站任一站点出现降水 | 0% |

